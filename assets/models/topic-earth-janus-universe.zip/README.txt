Janus Universe layer — 2026-09-30

Extract this archive OUTSIDE your topic.earth project.
Use exactly ONE patch, from your topic.earth Git checkout:

If you applied the earlier topic-earth-janus.zip package:
  git apply --check /path/to/patches/janus-universe-update.patch
  git apply /path/to/patches/janus-universe-update.patch

If you have the original GitHub version without that earlier patch:
  git apply --check /path/to/patches/janus-universe-full.patch
  git apply /path/to/patches/janus-universe-full.patch

The source/ folder contains editable files for review or a manual merge.
Do not first copy source/ files and then apply the patch.
If your local code differs, keep your changes and use Codex to merge the patch.

Run a local HTTP server from topic.earth, then choose Space > Universe > Janus.
There is exactly one Janus explanation topic. Selecting it enables the layer.
The uploaded GLB is included. It embeds its binary resources; the separate
.gltf and .bin files are not needed by this integration.

Verified in headless Chromium: model loading; Universe/Janus group and topic;
ratio controls; two animated time-arrow clips; pause/resume; solar-scene and
Earth-shell restoration; leaving Space; no JavaScript page errors.
Screenshot: preview.png.
The Blender generator has a syntax check only; it was not executed here.
Nothing was committed, pushed, or deployed.
